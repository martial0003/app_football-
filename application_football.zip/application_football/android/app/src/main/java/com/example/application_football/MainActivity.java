package com.example.application_football;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
