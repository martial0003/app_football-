import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:ligue1_app/models/match.dart';
import 'package:ligue1_app/services/api_service.dart';
import 'package:ligue1_app/screens/settings_screen.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:math';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  late ApiService _apiService;
  late Future<List<Match>> _matches;
  TextEditingController _searchController = TextEditingController();
  DateTime? _selectedDate;
  final _user = Supabase.instance.client.auth.currentUser;

  late List<AnimationController> _balloonControllers;
  late List<Animation<Offset>> _balloonAnimations;

  @override
  void initState() {
    super.initState();
    _apiService = ApiService();
    _matches = _apiService.getLiveScores();

    // Création des contrôleurs et animations pour plusieurs ballons
    _balloonControllers = [];
    _balloonAnimations = [];
    for (int i = 0; i < 5; i++) {  // Nombre de ballons
      final controller = AnimationController(
        vsync: this,
        duration: Duration(seconds: 3 + Random().nextInt(3)), // Durée aléatoire entre 3 et 5 secondes
      );
      final animation = Tween<Offset>(
        begin: Offset(
          Random().nextDouble() * 2 - 1, // Position horizontale aléatoire
          -1, // Toujours au-dessus de l'écran
        ),
        end: Offset(
          Random().nextDouble() * 2 - 1, // Position horizontale aléatoire
          1, // Position finale en bas de l'écran
        ),
      ).animate(CurvedAnimation(
        parent: controller,
        curve: Curves.easeInOut,
      ));

      _balloonControllers.add(controller);
      _balloonAnimations.add(animation);

      // Démarre les animations avec un délai aléatoire et les répète infiniment
      Future.delayed(Duration(seconds: Random().nextInt(4)), () {
        controller.repeat(reverse: true);  // Animation en boucle infinie
      });
    }
  }

  Future<void> _signOut() async {
    await Supabase.instance.client.auth.signOut();
    Navigator.pushReplacementNamed(context, '/login');
  }

  void _onDateSelected(DateTime date) {
    setState(() {
      _selectedDate = date;
      _matches = _apiService.getMatchesByTeamAndDate(_searchController.text, _selectedDate!);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text('Ligue1 Matches'),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime(2000),
                lastDate: DateTime(2101),
              ).then((selectedDate) {
                if (selectedDate != null) {
                  _onDateSelected(selectedDate);
                }
              });
            },
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    labelText: 'Rechercher par équipe',
                    border: OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: Icon(Icons.search),
                      onPressed: () {
                        setState(() {
                          _matches = _apiService.getMatchesByTeamAndDate(
                            _searchController.text,
                            _selectedDate ?? DateTime.now(),
                          );
                        });
                      },
                    ),
                  ),
                ),
              ),
              Expanded(
                child: FutureBuilder<List<Match>>(
                  future: _matches,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    }
                    if (snapshot.hasError) {
                      return SizedBox(); // Aucun message d'erreur à afficher
                    }
                    if (!snapshot.hasData || snapshot.data!.isEmpty) {
                      return Center(child: Text('Aucun match en direct.'));
                    }
                    return ListView.builder(
                      itemCount: snapshot.data!.length,
                      itemBuilder: (context, index) {
                        final match = snapshot.data![index];
                        return Card(
                          margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                          child: ListTile(
                            title: Text('${match.homeTeam} vs ${match.awayTeam}'),
                            subtitle: Text(
                              'Date: ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.parse(match.utcDate))} - '
                                  'Score: ${match.score.homeTeamScore} - ${match.score.awayTeamScore}',
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
          // Animation des ballons répartis aléatoirement sur l'écran
          ..._balloonAnimations.map((animation) {
            return SlideTransition(
              position: animation,
              child: Center(
                child: Icon(
                  Icons.sports_soccer,
                  size: 50 + Random().nextInt(20).toDouble(),
                  color: Colors.primaries[Random().nextInt(Colors.primaries.length)],
                ),
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(color: Colors.blue),
            accountName: Text(_user?.email ?? "Utilisateur inconnu"),
            accountEmail: Text(_user?.email ?? ""),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.person, size: 40, color: Colors.blue),
            ),
          ),
          _buildDrawerItem(Icons.home, 'Accueil', '/home'),
          _buildDrawerItem(Icons.live_tv, 'Scores en Direct', '/live'),
          _buildDrawerItem(Icons.favorite, 'Favoris', '/favorites'),
          _buildDrawerItem(Icons.article, 'Actualités', '/news'),
          _buildDrawerItem(Icons.insert_chart, 'Classements', '/standings'),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('Paramètres'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => SettingsScreen(
                    onLanguageChange: (newLang) {},
                    onTeamChange: (newTeam) {},
                  ),
                ),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.logout),
            title: Text('Déconnexion'),
            onTap: _signOut,
          ),
        ],
      ),
    );
  }

  ListTile _buildDrawerItem(IconData icon, String title, String route) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      onTap: () {
        Navigator.pushNamed(context, route);
      },
    );
  }
}
