// standings_screen.dart
import 'package:flutter/material.dart';

class StandingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Classement'),
      ),
      body: Center(
        child: Text('Classement du championnat ici'),
      ),
    );
  }
}
