import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async'; // Importation pour utiliser Timer

class NewsScreen extends StatefulWidget {
  @override
  _NewsScreenState createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  bool _isLoading = false;
  List<dynamic> _articles = [];
  String _errorMessage = '';

  // URL de l'API NewsAPI pour récupérer les actualités liées à la Ligue 1
  final String _apiUrl =
      'https://newsapi.org/v2/everything?q=Ligue+1&apiKey=6de065a02c3949c09f23b271936096bf';

  // Timer pour actualiser les données
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _fetchNews();

    // Lancer la mise à jour automatique toutes les 30 secondes
    _timer = Timer.periodic(Duration(seconds: 30), (Timer t) => _fetchNews());
  }

  // Fonction pour récupérer les actualités
  Future<void> _fetchNews() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final response = await http.get(Uri.parse(_apiUrl));

      if (response.statusCode == 200) {
        // Si la requête réussie, on décode les données JSON
        var data = json.decode(response.body);
        setState(() {
          _articles = data['articles'];
          _isLoading = false;
        });
      } else {
        // Si la réponse n'est pas OK, on lève une exception
        throw Exception('Erreur API: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Erreur de récupération des données: $e';
      });
      print('Erreur lors de la récupération des actualités: $e');
    }
  }

  @override
  void dispose() {
    // Annuler le timer quand l'écran est fermé
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Actualités de la Ligue 1'),
        backgroundColor: Colors.blue,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _errorMessage.isNotEmpty
          ? Center(child: Text(_errorMessage))
          : ListView.builder(
        itemCount: _articles.length,
        itemBuilder: (context, index) {
          final article = _articles[index];
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              title: Text(article['title'] ?? 'Titre indisponible'),
              subtitle: Text(
                article['description'] ?? 'Aucune description',
              ),
              onTap: () {
                // Action à effectuer lorsque l'utilisateur clique sur un article
                print('Article cliqué: ${article['title']}');
              },
            ),
          );
        },
      ),
    );
  }
}
