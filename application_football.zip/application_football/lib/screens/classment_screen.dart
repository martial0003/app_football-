// lib/screens/classment_screen.dart
import 'package:flutter/material.dart';
import 'package:ligue1_app/services/api_service.dart'; // Assure-toi que c'est bien importé
import 'package:ligue1_app/models/classment.dart'; // Si tu as un modèle pour le classement

class ClassmentScreen extends StatefulWidget {
  @override
  _ClassmentScreenState createState() => _ClassmentScreenState();
}

class _ClassmentScreenState extends State<ClassmentScreen> {
  bool _isLoading = false;
  List<dynamic> _standings = [];
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _fetchStandings();
  }

  // Récupérer le classement depuis l'API
  Future<void> _fetchStandings() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final standings = await ApiService().fetchClassment(); // Utilise fetchClassment() ici
      setState(() {
        _standings = standings;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Erreur de récupération des données: $e';
      });
      print('Erreur lors de la récupération du classement: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Classement Ligue 1'),
        backgroundColor: Colors.blue,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _errorMessage.isNotEmpty
          ? Center(child: Text(_errorMessage))
          : ListView.builder(
        itemCount: _standings.length,
        itemBuilder: (context, index) {
          final team = _standings[index];
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              leading: Text((index + 1).toString()),
              title: Text(team['team']['name']),
              subtitle: Text(
                'Points: ${team['points']} - Diff. de buts: ${team['goalDifference']}',
              ),
              trailing: Text(
                'Joués: ${team['playedGames']}',
              ),
            ),
          );
        },
      ),
    );
  }
}
