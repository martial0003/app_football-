import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:ligue1_app/models/match.dart'; // Importation du modèle Match
import 'package:ligue1_app/services/api_service.dart';

class LiveScoresScreen extends StatefulWidget {
  @override
  _LiveScoresScreenState createState() => _LiveScoresScreenState();
}

class _LiveScoresScreenState extends State<LiveScoresScreen> {
  late ApiService _apiService;
  late Future<List<Match>> _matches;

  @override
  void initState() {
    super.initState();
    _apiService = ApiService();
    _matches = _apiService.getLiveScores(); // Récupération des scores en direct
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue, // Fond bleu pour l'AppBar
        title: Text('Scores en Direct'),
      ),
      body: FutureBuilder<List<Match>>(
        future: _matches,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Erreur: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Aucun match en direct.'));
          }

          final matches = snapshot.data!;

          return ListView.builder(
            itemCount: matches.length,
            itemBuilder: (context, index) {
              final match = matches[index];
              return Card(
                margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                child: ListTile(
                  title: Text('${match.homeTeam} vs ${match.awayTeam}'),
                  subtitle: Text(
                    'Date: ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.parse(match.utcDate))} - '
                        'Score: ${match.score.homeTeamScore} - ${match.score.awayTeamScore}', // Utilisation des scores des équipes
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
