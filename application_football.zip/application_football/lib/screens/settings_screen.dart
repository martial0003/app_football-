import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  final Function(String) onLanguageChange;  // Paramètre pour gérer le changement de langue
  final Function(String) onTeamChange;  // Paramètre pour gérer le changement d'équipe

  SettingsScreen({required this.onLanguageChange, required this.onTeamChange});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Réglages')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Option pour changer la langue
            ListTile(
              title: Text('Changer la langue'),
              onTap: () {
                _showLanguageDialog(context);
              },
            ),
            // Option pour choisir l’équipe préférée
            ListTile(
              title: Text('Choisir ton équipe préférée'),
              onTap: () {
                _showTeamDialog(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  // Affiche un dialogue pour changer la langue
  void _showLanguageDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Choisir la langue"),
          content: DropdownButton<String>(
            onChanged: (String? newValue) {
              if (newValue != null) {
                onLanguageChange(newValue);  // Appel de la fonction pour changer la langue
                Navigator.pop(context);  // Ferme le dialogue après sélection
              }
            },
            items: <String>['fr', 'en', 'es', 'de', 'it', 'pt']
                .map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value.toUpperCase()),  // Affiche la langue en majuscules
              );
            }).toList(),
          ),
        );
      },
    );
  }

  // Affiche un dialogue pour choisir l'équipe préférée
  void _showTeamDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Choisir ton équipe préférée"),
          content: DropdownButton<String>(
            onChanged: (String? newValue) {
              if (newValue != null) {
                onTeamChange(newValue);  // Appel de la fonction pour changer l'équipe
                Navigator.pop(context);  // Ferme le dialogue après sélection
              }
            },
            items: <String>[
              'Paris Saint-Germain', 'Olympique de Marseille', 'AS Monaco', 'Lille OSC', 'OL Lyon', 'AS Saint-Étienne',
              'RC Lens', 'Nice', 'Rennes', 'Montpellier HSC', 'Brest', 'Nantes', 'Lorient', 'Strasbourg', 'Troyes', 'Reims',
              'Angers SCO', 'Clermont Foot', 'Ajaccio'
            ]
                .map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
        );
      },
    );
  }
}
