import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthHelper {
  static final SupabaseClient supabase = Supabase.instance.client;

  /// 🔹 Connexion avec Google
  static Future<void> signInWithGoogle(BuildContext context) async {
    try {
      await supabase.auth.signInWithOAuth(
        Provider.google,
        redirectTo: 'http://localhost:3000', // Change si tu es sur mobile
      );
    } catch (e) {
      _showError(context, 'Erreur Google Sign-In : $e');
    }
  }

  /// 🔹 Déconnexion
  static Future<void> signOut(BuildContext context) async {
    try {
      await supabase.auth.signOut();
    } catch (e) {
      _showError(context, 'Erreur lors de la déconnexion : $e');
    }
  }

  /// 🔹 Vérifier si un utilisateur est connecté
  static User? getCurrentUser() {
    return supabase.auth.currentUser;
  }

  /// 🔹 Afficher une erreur
  static void _showError(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }
}
