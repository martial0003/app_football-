// lib/drawers/ligue1_drawer.dart
import 'package:flutter/material.dart';
import 'package:ligue1_app/screens/classment_screen.dart';  // Remplacer par le nom de ton projet

class Ligue1Drawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
            child: Text(
              'Ligue 1',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
          ),
          ListTile(
            title: Text('Classement Ligue 1'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ClassmentScreen(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
