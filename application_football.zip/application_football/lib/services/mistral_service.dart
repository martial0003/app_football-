import 'dart:convert';
import 'package:http/http.dart' as http;

class MistralService {
  final String apiKey = 'WJapYiK0h6OKnsFQ67i28PHd1muLf6Ex'; // Remplace avec ta clé API Mistral
  final String apiUrl = 'https://api.mistral.ai/v1/completions'; // URL de l'API Mistral

  // Méthode pour générer du texte
  Future<String> generateText(String prompt) async {
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $apiKey',  // Authentification avec la clé API
    };

    final body = json.encode({
      "model": "mistral-7b-instruct",  // Nom du modèle Mistral (exemple)
      "prompt": prompt,
      "max_tokens": 100,  // Nombre de tokens de réponse
      "temperature": 0.7,  // Niveau de créativité de la réponse
    });

    try {
      final response = await http.post(Uri.parse(apiUrl), headers: headers, body: body);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['choices'][0]['text'].toString().trim();
      } else {
        throw Exception('Échec de la génération du texte via Mistral AI');
      }
    } catch (e) {
      throw Exception('Erreur lors de la requête : $e');
    }
  }

  // Méthode pour poser une question, qui utilise generateText en interne
  Future<String> askQuestion(String question) async {
    return await generateText(question);  // Utilisation de la méthode generateText
  }
}
