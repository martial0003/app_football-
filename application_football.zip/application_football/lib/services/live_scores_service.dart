// services/live_scores_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

class LiveScoresService {
  final String apiKey = 'ae0316d1efed4c41a1119353f300df95'; // Remplace avec ta clé API
  final String apiUrl = 'https://api.football-data.org/v4/matches'; // URL de l'API

  Future<List<Map<String, dynamic>>> fetchLiveScores() async {
    final response = await http.get(
      Uri.parse(apiUrl),
      headers: {'X-Auth-Token': apiKey},
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      List matches = data['matches'];
      return matches.map((match) {
        return {
          'homeTeam': match['homeTeam']['name'],
          'awayTeam': match['awayTeam']['name'],
          'score': match['score']['fullTime'],
          'status': match['status'],
        };
      }).toList();
    } else {
      throw Exception('Erreur lors de la récupération des scores');
    }
  }
}
