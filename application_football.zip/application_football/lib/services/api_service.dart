// lib/services/api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ligue1_app/models/match.dart';
import 'package:ligue1_app/models/match_details.dart';

class ApiService {
  final String _baseUrl = 'https://api.football-data.org/v4';
  final String _apiToken = 'ae0316d1efed4c41a1119353f300df95'; // Ton token API ici

  // En-tête commun pour toutes les requêtes
  Map<String, String> get _headers => {
    'X-Auth-Token': _apiToken,
  };

  // Méthode pour obtenir les scores en direct
  Future<List<Match>> getLiveScores() async {
    try {
      final response = await http.get(Uri.parse('$_baseUrl/matches'), headers: _headers);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        List<dynamic> matchesJson = data['matches'];
        return matchesJson.map((matchJson) => Match.fromJson(matchJson)).toList();
      } else {
        throw Exception('Erreur lors du chargement des scores en direct : ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erreur lors de la récupération des scores en direct: $e');
    }
  }

  // Méthode pour obtenir les détails d'un match
  Future<MatchDetails> getMatchDetails(String matchId) async {
    try {
      final response = await http.get(Uri.parse('$_baseUrl/matches/$matchId'), headers: _headers);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return MatchDetails.fromJson(data);
      } else {
        throw Exception('Erreur lors du chargement des détails du match : ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erreur lors de la récupération des détails du match: $e');
    }
  }

  // Méthode pour obtenir les matchs par équipe et date
  Future<List<Match>> getMatchesByTeamAndDate(String team, DateTime date) async {
    // Si la date est nulle, utiliser la date actuelle comme valeur par défaut
    date ??= DateTime.now();

    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/matches?team=$team&date=${date.toIso8601String()}'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        List<dynamic> matchesJson = data['matches'];
        return matchesJson.map((matchJson) => Match.fromJson(matchJson)).toList();
      } else {
        throw Exception('Erreur lors du chargement des matchs par équipe et date : ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erreur lors de la récupération des matchs : $e');
    }
  }

  // Méthode pour effectuer une recherche de matchs par équipe
  Future<List<Match>> searchMatches(String query) async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/matches?team=$query'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        List<dynamic> matchesJson = data['matches'];
        return matchesJson.map((matchJson) => Match.fromJson(matchJson)).toList();
      } else {
        throw Exception('Erreur lors de la recherche des matchs : ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erreur lors de la recherche de matchs : $e');
    }
  }

  // Nouvelle méthode pour récupérer le classement
  Future<List<dynamic>> fetchClassment() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/competitions/FL1/standings'), // URL pour obtenir le classement de la Ligue 1
        headers: _headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['standings'][0]['table']; // Retourne le tableau des équipes
      } else {
        throw Exception('Erreur lors du chargement du classement : ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erreur lors de la récupération du classement : $e');
    }
  }
}
