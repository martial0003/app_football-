import 'package:flutter/foundation.dart'; // Pour détecter Web ou Mobile
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  final SupabaseClient supabase = Supabase.instance.client;

  /// Connexion avec Google
  Future<void> signInWithGoogle() async {
    try {
      // Détecte si on est en Web ou Mobile et ajuste l'URL dynamiquement
      final redirectTo = kIsWeb
          ? Uri.base.origin // Utilise l'URL actuelle de l'application (utile en prod)
          : 'io.supabase.flutter://callback'; // Mobile (iOS/Android)

      await supabase.auth.signInWithOAuth(
        Provider.google,
        redirectTo: redirectTo,
      );
    } catch (e) {
      print("Erreur d'authentification Google : $e");
      throw Exception("Impossible de se connecter avec Google.");
    }
  }

  /// Déconnexion
  Future<void> signOut() async {
    try {
      await supabase.auth.signOut();
    } catch (e) {
      print("Erreur lors de la déconnexion : $e");
    }
  }

  /// Vérifie si l'utilisateur est connecté
  User? getCurrentUser() {
    return supabase.auth.currentUser;
  }
}
