import 'dart:convert';
import 'package:http/http.dart' as http;

class NewsService {
  // Remplace cette URL par l'URL réelle de l'API de Mistral ou d'une autre source
  static const String _apiUrl = 'https://www.api-football.com/';

  // Récupérer les actualités
  Future<List<Map<String, dynamic>>> getNews() async {
    final response = await http.get(Uri.parse(_apiUrl));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      // Retourner les données sous forme de liste
      return List<Map<String, dynamic>>.from(data['articles']);
    } else {
      throw Exception('Erreur de chargement des actualités');
    }
  }
}
