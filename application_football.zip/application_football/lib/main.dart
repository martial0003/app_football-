import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart'; // Ajout de l'importation nécessaire
import 'package:supabase_flutter/supabase_flutter.dart';

import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/live_scores_screen.dart';  // Importation de l'écran des scores en direct
import 'screens/favorites_screen.dart';   // Importation de l'écran des favoris
import 'screens/news_screen.dart';        // Importation de l'écran des actualités
import 'screens/classment_screen.dart';   // Importation de l'écran du classement
import 'utils/constants.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialisation de Supabase avec les clés stockées dans constants.dart
  await Supabase.initialize(
    url: supabaseUrl,
    anonKey: supabaseAnonKey,
  );

  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String _currentLanguage = 'fr'; // Valeur par défaut en français
  String _currentTeam = 'Paris Saint-Germain'; // Équipe par défaut

  void _changeLanguage(String newLanguage) {
    setState(() {
      _currentLanguage = newLanguage;
    });
  }

  void _changeTeam(String newTeam) {
    setState(() {
      _currentTeam = newTeam;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: AuthWrapper(),
      routes: {
        '/settings': (context) => SettingsScreen(
          onLanguageChange: _changeLanguage,
          onTeamChange: _changeTeam,
        ),
        '/home': (context) => HomeScreen(),
        '/login': (context) => LoginScreen(),
        '/live': (context) => LiveScoresScreen(), // Nouvelle route pour les scores en direct
        '/favorites': (context) => FavoritesScreen(), // Nouvelle route pour les favoris
        '/news': (context) => NewsScreen(), // Nouvelle route pour les actualités
        '/classment': (context) => ClassmentScreen(), // Nouvelle route pour le classement
      },
      locale: Locale(_currentLanguage), // Définit la langue locale
      supportedLocales: [
        Locale('fr', ''), // Français
        Locale('en', ''), // Anglais
        // Tu peux ajouter d'autres langues ici si nécessaire
      ],
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
    );
  }
}

class AuthWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final session = Supabase.instance.client.auth.currentSession;
    // Si la session est active, on redirige vers la HomeScreen, sinon vers la LoginScreen
    return session != null ? HomeScreen() : LoginScreen();
  }
}
