class News {
  final String title;
  final String description;
  final String imageUrl;
  final DateTime date;

  News({
    required this.title,
    required this.description,
    required this.imageUrl,
    required this.date,
  });

// Ajoutez une factory fromJson si vous utilisez une API pour les actualités
}