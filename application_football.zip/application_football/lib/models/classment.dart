// lib/models/classment.dart

class Classment {
  final String teamName;
  final int points;
  final int goalDifference;
  final int playedGames;

  Classment({
    required this.teamName,
    required this.points,
    required this.goalDifference,
    required this.playedGames,
  });

  // Méthode pour convertir les données JSON en objet Classment
  factory Classment.fromJson(Map<String, dynamic> json) {
    return Classment(
      teamName: json['team']['name'],
      points: json['points'],
      goalDifference: json['goalDifference'],
      playedGames: json['playedGames'],
    );
  }
}
