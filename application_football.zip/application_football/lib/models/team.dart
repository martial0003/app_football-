class Team {
  final String id;
  final String name;
  final String logoUrl;
  final int position;

  Team({
    required this.id,
    required this.name,
    required this.logoUrl,
    required this.position,
  });

  factory Team.fromJson(Map<String, dynamic> json) {
    return Team(
      id: json['id'],
      name: json['name'],
      logoUrl: json['crestUrl'],
      position: json['position'],
    );
  }
}