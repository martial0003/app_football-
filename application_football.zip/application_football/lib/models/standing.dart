class Standing {
  final int position;
  final String teamName;
  final int points;
  final int playedGames;
  final int goalDifference;

  Standing({
    required this.position,
    required this.teamName,
    required this.points,
    required this.playedGames,
    required this.goalDifference,
  });

  factory Standing.fromJson(Map<String, dynamic> json) {
    return Standing(
      position: json['position'],
      teamName: json['team']['name'],
      points: json['points'],
      playedGames: json['playedGames'],
      goalDifference: json['goalDifference'],
    );
  }
}
