// lib/models/match.dart
import 'score.dart';  // Import de la classe Score

class Match {
  final String homeTeam;
  final String awayTeam;
  final String utcDate;
  final Score score;  // Utilisation de la classe Score
  final String matchId;  // Identifiant unique du match

  Match({
    required this.homeTeam,
    required this.awayTeam,
    required this.utcDate,
    required this.score,
    required this.matchId,
  });

  factory Match.fromJson(Map<String, dynamic> json) {
    return Match(
      homeTeam: json['homeTeam']['name'],
      awayTeam: json['awayTeam']['name'],
      utcDate: json['utcDate'],
      score: Score.fromJson(json['score']),  // Utilisation de Score
      matchId: json['id'].toString(),  // Assurez-vous que 'id' est présent dans l'API
    );
  }
}
