class Competition {
  final int id;
  final String name;
  final String code;
  final String area;

  Competition({
    required this.id,
    required this.name,
    required this.code,
    required this.area,
  });

  factory Competition.fromJson(Map<String, dynamic> json) {
    return Competition(
      id: json['id'],
      name: json['name'],
      code: json['code'],
      area: json['area']['name'],
    );
  }
}
