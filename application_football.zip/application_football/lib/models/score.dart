// lib/models/score.dart
class Score {
  final int homeTeamScore;
  final int awayTeamScore;

  Score({
    required this.homeTeamScore,
    required this.awayTeamScore,
  });

  factory Score.fromJson(Map<String, dynamic> json) {
    return Score(
      homeTeamScore: json['homeTeam']['score'],
      awayTeamScore: json['awayTeam']['score'],
    );
  }
}
