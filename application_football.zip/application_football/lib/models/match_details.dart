// lib/models/match_details.dart
class MatchDetails {
  final String homeTeam;
  final String awayTeam;
  final String scoreHome;
  final String scoreAway;
  final DateTime utcDate;
  final String id;

  MatchDetails({
    required this.homeTeam,
    required this.awayTeam,
    required this.scoreHome,
    required this.scoreAway,
    required this.utcDate,
    required this.id,
  });

  factory MatchDetails.fromJson(Map<String, dynamic> json) {
    return MatchDetails(
      homeTeam: json['homeTeam']['name'],
      awayTeam: json['awayTeam']['name'],
      scoreHome: json['score']['fullTime']['homeTeam'].toString(),
      scoreAway: json['score']['fullTime']['awayTeam'].toString(),
      utcDate: DateTime.parse(json['utcDate']),
      id: json['id'].toString(),
    );
  }
}
